"""Core utilities for Dragon Funded support bot."""

from .config import get_settings

__all__ = ["get_settings"]








