"""Application package initialization for Prop Firm Dragon Funded support bot."""

from .main import create_app

__all__ = ["create_app"]








